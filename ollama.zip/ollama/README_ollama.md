# Intelligent Layer with Ollama — Setup and Run Guide

This guide walks you through running the Intelligent Layer pipeline end-to-end on your own machine, using Ollama (free, local LLM runtime) to drive the two language-model stages (NL → SPARQL translation and response synthesis). All other components — schema extraction, SPARQL execution against CorpOnto, and PROV-O lineage enrichment — run deterministically against your two ontology files.

## What you need

- A computer with **at least 8 GB of RAM** (16 GB is comfortable). The two default models together need ~4 GB of memory while running.
- Around **5 GB of free disk space** for the models.
- Python 3.9 or newer.
- Your two ontology files: `CorpOnto.owl` and `proveniencia.owl`.

The pipeline runs on CPU. A GPU is not required.

---

## Step 1 — Install Ollama

Ollama is a free, open-source runtime for local LLMs. It's the simplest way to run small models without any cloud account.

**macOS** (recommended for Apple Silicon):
```bash
brew install ollama
```
or download the installer from https://ollama.com/download.

**Linux**:
```bash
curl -fsSL https://ollama.com/install.sh | sh
```

**Windows**: download the installer from https://ollama.com/download.

After installing, start the Ollama server. On macOS the desktop app starts it automatically. On Linux/Windows, run in a separate terminal:
```bash
ollama serve
```

Leave that terminal open. Ollama is now listening on `http://localhost:11434`.

---

## Step 2 — Pull the two models

Open another terminal (keep `ollama serve` running) and pull the two default models. The pipeline uses a small coder-tuned model for SPARQL generation and a general model for response synthesis.

```bash
ollama pull qwen2.5-coder:1.5b
ollama pull llama3.2:3b
```

Each is ~1–2 GB. Download takes a few minutes on a typical connection.

Verify both are installed:
```bash
ollama list
```

You should see both models in the output.

Quick sanity check that the server is responding:
```bash
ollama run qwen2.5-coder:1.5b "Write a SPARQL query that selects all subjects"
```
You should get a SPARQL snippet back. Press Ctrl-D or `/bye` to exit.

---

## Step 3 — Install Python dependencies

In the directory where you have the pipeline code (the `intelligent_layer/` folder):

```bash
pip install owlready2 rdflib ollama
```

That's it. No PyTorch, no Transformers, no Hugging Face — Ollama handles all the model serving.

---

## Step 4 — Place your ontology files

Put `CorpOnto.owl` and `proveniencia.owl` somewhere on disk. The pipeline accepts paths as command-line arguments. For convenience you can put them next to the pipeline scripts, e.g.:

```
intelligent_layer/
├── schema_extractor.py
├── executor.py
├── ollama_clients.py
├── pipeline_ollama.py
├── CorpOnto.owl           ← here
└── proveniencia.owl       ← here
```

---

## Step 5 — Run the full pipeline

From inside `intelligent_layer/`:

```bash
python3 pipeline_ollama.py \
  --corponto ./CorpOnto.owl \
  --proveniencia ./proveniencia.owl
```

(Or omit the paths if you placed the files at `/home/claude/`, which is the default.)

The pipeline will:

1. **Check Ollama connectivity.** If the server isn't running or the models aren't pulled, it fails with a clear message telling you exactly what to do.
2. **Extract schema** from `CorpOnto.owl` (~150 ms, deterministic).
3. **Load both ontologies** into the in-memory triplestore.
4. **For each of the 18 questions**:
   - Send the question + schema to `qwen2.5-coder:1.5b` and parse the generated SPARQL.
   - Execute the generated SPARQL against the populated Gold ontology.
   - Enrich the result with provenance lineage from PROV-O.
   - Also execute the hand-curated reference SPARQL and compare result sets.
   - Send the question + SPARQL + results to `llama3.2:3b` for the natural-language answer.
   - Record per-stage latency.
5. **Print aggregate statistics**: SPARQL correctness (exact / partial / no match against the reference), median latency per stage, end-to-end latency.
6. **Save a full JSON report** to `intelligent_layer_ollama_results.json`.

Expected total runtime: roughly **5–15 minutes** depending on your machine. The two LLM stages dominate; SPARQL execution is in milliseconds.

---

## Step 6 — Read the results

The console will show, for each question:
- The generated SPARQL (first 10 lines)
- How many rows the LLM's SPARQL returned, vs. how many the reference SPARQL returned
- A correctness label (`exact_match`, `partial_match`, `no_match`)
- The natural-language answer produced by the synthesis model
- Per-stage latency

The aggregate at the end summarizes:
- **SPARQL correctness rate**: how often the LLM's SPARQL produced the same answers as the reference
- **Median latency** per stage
- **End-to-end latency** distribution

The JSON report (`intelligent_layer_ollama_results.json`) contains everything: every generated SPARQL, every row of results, every answer, every timing measurement. You can grep, analyze, or paste it directly into the paper.

---

## Useful flags

Run a subset of questions for a quick test:
```bash
python3 pipeline_ollama.py --questions 1,4,13
```

Skip the synthesis stage (faster, no Llama needed):
```bash
python3 pipeline_ollama.py --no-synth
```

Try different models:
```bash
python3 pipeline_ollama.py --sparql-model qwen2.5-coder:3b --synth-model llama3.2:1b
```

Use a remote Ollama server:
```bash
python3 pipeline_ollama.py --ollama-host http://192.168.1.20:11434
```

---

## What to report in the paper

After the run completes, you'll have hard numbers to replace the mock-derived numbers currently in Section 6.6 and Table 5 of the paper. Specifically:

| Currently reported (from mocks) | What to replace it with |
|---|---|
| "non-empty answer rate 88.9%" | The **SPARQL correctness rate** computed against the hand-curated reference. This is a stronger metric: it measures whether the LLM produced **semantically correct** SPARQL, not just whether SPARQL ran. |
| "SPARQL exec median 6.5 ms" | Keep this number — it's already real (deterministic component). |
| (no latency reported for LLM stages) | Add the real median latencies for NL→SPARQL and synthesis. |
| "Mock implementations in place of live language-model calls" | Remove this limitation entirely. Replace with the actual model names and versions used. |

---

## Pipeline architecture summary

```
                      ┌─────────────────────────────────┐
                      │  CorpOnto.owl (Gold ontology)   │
                      │  proveniencia.owl (PROV-O)      │
                      └──────────────┬──────────────────┘
                                     │
              ┌──────────────────────┴──────────────────────┐
              │  schema_extractor.py   (deterministic)      │
              │  → compact schema text for LLM context      │
              └──────────────────────┬──────────────────────┘
                                     │
   User question  ────────►  ┌───────┴────────────┐
   (EN or PT)                │ ollama_clients.py  │  qwen2.5-coder:1.5b
                             │ NL → SPARQL        │  (local, via Ollama)
                             └───────┬────────────┘
                                     │
                                     ▼
                             ┌────────────────────┐
                             │ executor.py        │
                             │ SPARQL execution   │  ← rdflib + owlready2
                             │ + lineage from     │     (deterministic)
                             │ proveniencia.owl   │
                             └───────┬────────────┘
                                     │
                                     ▼
                             ┌────────────────────┐
                             │ ollama_clients.py  │  llama3.2:3b
                             │ Response synthesis │  (local, via Ollama)
                             └───────┬────────────┘
                                     │
                                     ▼
                     NL answer with citations + provenance footer
```

---

## Troubleshooting

**"Ollama server not reachable"**: start it with `ollama serve` in a separate terminal. On macOS, also try opening the Ollama desktop app.

**"missing Ollama models"**: run the `ollama pull` commands from Step 2.

**Out of memory during a run**: try a smaller synthesis model: `--synth-model llama3.2:1b`. Or use `--no-synth` to skip that stage entirely.

**Generated SPARQL fails to execute**: the pipeline logs the execution error in the JSON report. Common causes are the LLM inventing a property name not in the ontology (look at the `generated_sparql` field in the JSON). The pipeline keeps going and records this as `no_match` correctness.

**Very slow on the first question, fast afterwards**: Ollama loads the model into memory on first use. Subsequent questions reuse it. The first question's latency is not representative.

**Want to validate Ollama is set up correctly before a long run**: use `--questions 1` to run a single question end-to-end first.

---

## Where each artifact ends up

- **Console output**: human-readable summary, printed live during the run.
- **`intelligent_layer_ollama_results.json`**: machine-readable record of every step.

Both can be copied into the paper directly or used as supplementary material.
