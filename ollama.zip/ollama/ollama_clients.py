"""
Ollama-backed implementations of the two LLM-dependent stages of the
Intelligent Layer:
  - OllamaNLToSPARQL : translates a natural-language question into a SPARQL
                       query, conditioned on the CorpOnto schema.
  - OllamaResponseSynthesizer : produces a natural-language answer that cites
                                each returned individual and a provenance footer.

Both classes call a locally-running Ollama server (default: http://localhost:11434).
Default models are chosen to be small enough to run on a laptop CPU:
  - SPARQL generation : qwen2.5-coder:1.5b (a coder-tuned model good for code)
  - response synthesis: llama3.2:3b        (a general-purpose instruct model)

You can override the model names from the command line or by editing the
pipeline script.

Usage example:
    >>> from ollama_clients import OllamaNLToSPARQL
    >>> tr = OllamaNLToSPARQL(schema_text="...", model="qwen2.5-coder:1.5b")
    >>> sparql, meta = tr.translate("Quais funcionários sabem Python?")
"""
import re
import time
import ollama


# ============================================================
# SYSTEM PROMPTS
# ============================================================

NS_URI = "http://www.semanticweb.org/anon/ontologies/2025/8/CorpOnto.owl#"

SPARQL_SYSTEM_PROMPT = """You translate natural-language questions (English or Portuguese) into SPARQL queries against a corporate ontology. The ontology schema is shown below.

{schema}

RULES:
1. Output ONLY a valid SPARQL query wrapped in ```sparql ... ``` fences. No explanation, no commentary.
2. Always include the namespace prefix:
   PREFIX : <{ns}>
3. Use SELECT DISTINCT to avoid duplicates.
4. Employee instances do NOT have a hasName property; they are identified by IRI (e.g. :Employee_001). Only Profile, Knowledge, Customer, BusinessPartner have :hasName.
5. For numeric thresholds use FILTER with comparison operators.
6. If the question cannot be answered from this ontology, output:
   ```sparql
   # CANNOT_ANSWER: <one-sentence reason>
   ```
7. Portuguese terminology mapping: "funcionário"=Employee, "projeto"=Project, "oportunidade"=Opportunity, "proposta técnica"=TechnicalProposal, "proposta comercial"=CommercialProposal, "perfil"=Profile, "conhecimento"=Knowledge, "margem"=margin, "cliente"=Customer, "fornecedor"=Supplier, "fatura"=Invoice, "pagamento"=Payment.

EXAMPLES:

Q: Which opportunities have a technical proposal with a cost estimate?
```sparql
PREFIX : <{ns}>
SELECT DISTINCT ?opp WHERE {{
  ?opp a :Opportunity .
  ?opp :hasTechnicalProposal ?tp .
  ?tp :technicalProposalNeedsToWorkHourProfile ?whp .
  ?whp :expectedHours ?h .
}}
```

Q: Quais funcionários conhecem Python?
```sparql
PREFIX : <{ns}>
SELECT DISTINCT ?emp ?profile WHERE {{
  ?emp a :Employee .
  ?emp :hasKnowledge ?k .
  ?k :hasName "Python" .
  OPTIONAL {{ ?emp :hasProfile ?p . ?p :hasName ?profile . }}
}}
```

Q: Quais projetos tiveram margem real acima de 25%?
```sparql
PREFIX : <{ns}>
SELECT DISTINCT ?project ?margin WHERE {{
  ?project a :Project .
  ?project :hasRealMargin ?margin .
  FILTER(?margin > 0.25)
}}
ORDER BY DESC(?margin)
```
"""


RESPONSE_SYSTEM_PROMPT = """You are an enterprise analytics assistant grounded in a corporate ontology. You receive a user question, the SPARQL query that was executed, the results returned by the ontology, and the provenance lineage of the data.

Produce a concise natural-language answer that:
1. Directly answers the user's question.
2. Cites each ontological individual using the format [IndividualName].
3. Includes a brief note at the end indicating that the underlying data traversed the Source -> Kafka -> Bronze -> Silver -> Gold pipeline.
4. Uses the same language as the question (Portuguese or English).
5. Does NOT invent facts not present in the results. If the result set is empty, say so plainly.
6. Plain prose, no markdown headers or bold.
7. Be brief: 2 to 4 sentences total.
"""


# ============================================================
# OLLAMA CLIENT WRAPPERS
# ============================================================

class OllamaNLToSPARQL:
    def __init__(self, schema_text, model="qwen2.5-coder:1.5b",
                 host="http://localhost:11434", temperature=0.0):
        self.client = ollama.Client(host=host)
        self.system_prompt = SPARQL_SYSTEM_PROMPT.format(
            schema=schema_text, ns=NS_URI
        )
        self.model = model
        self.temperature = temperature

    def translate(self, question):
        """Return (sparql_string, meta_dict).
        meta_dict contains: latency_ms, model, prompt_tokens, response_tokens."""
        t0 = time.perf_counter()
        try:
            response = self.client.chat(
                model=self.model,
                messages=[
                    {"role": "system", "content": self.system_prompt},
                    {"role": "user", "content": question},
                ],
                options={"temperature": self.temperature},
            )
        except Exception as e:
            return f"# CANNOT_ANSWER: Ollama call failed: {e}", {
                "latency_ms": round((time.perf_counter() - t0) * 1000, 2),
                "model": self.model,
                "error": str(e),
            }
        elapsed_ms = (time.perf_counter() - t0) * 1000

        text = response["message"]["content"]
        # Extract SPARQL from fence
        match = re.search(r"```sparql\s*\n(.*?)```", text, re.DOTALL)
        sparql = match.group(1).strip() if match else text.strip()

        meta = {
            "latency_ms": round(elapsed_ms, 2),
            "model": self.model,
            "prompt_tokens": response.get("prompt_eval_count"),
            "response_tokens": response.get("eval_count"),
            "raw_response_first200": text[:200],
        }
        return sparql, meta


class OllamaResponseSynthesizer:
    def __init__(self, model="llama3.2:3b",
                 host="http://localhost:11434", temperature=0.2):
        self.client = ollama.Client(host=host)
        self.model = model
        self.temperature = temperature

    def synthesize(self, question, sparql, exec_result):
        """Return (nl_answer_string, meta_dict)."""
        context = self._format_context(question, sparql, exec_result)
        t0 = time.perf_counter()
        try:
            response = self.client.chat(
                model=self.model,
                messages=[
                    {"role": "system", "content": RESPONSE_SYSTEM_PROMPT},
                    {"role": "user", "content": context},
                ],
                options={"temperature": self.temperature},
            )
        except Exception as e:
            return f"[Synthesis failed: {e}]", {
                "latency_ms": round((time.perf_counter() - t0) * 1000, 2),
                "error": str(e),
            }
        elapsed_ms = (time.perf_counter() - t0) * 1000
        text = response["message"]["content"].strip()

        meta = {
            "latency_ms": round(elapsed_ms, 2),
            "model": self.model,
            "prompt_tokens": response.get("prompt_eval_count"),
            "response_tokens": response.get("eval_count"),
        }
        return text, meta

    def _format_context(self, question, sparql, exec_result):
        parts = [
            f"USER QUESTION: {question}",
            "",
            "SPARQL QUERY EXECUTED:",
            sparql,
            "",
            f"RESULTS ({exec_result['n_rows']} rows):",
        ]
        if exec_result["n_rows"] == 0:
            parts.append("(empty result set)")
        else:
            for row in exec_result["rows"][:50]:
                parts.append(
                    "  " + " | ".join((c["value"] or "-") for c in row)
                )
        if exec_result.get("lineage"):
            parts.append("")
            parts.append("PROVENANCE LINEAGE:")
            for ind, lineage in list(exec_result["lineage"].items())[:5]:
                chain = " <- ".join(
                    f"[{s['stage']}] {s['entity']}" for s in lineage
                )
                parts.append(f"  {ind}: {chain}")
        return "\n".join(parts)


# ============================================================
# Helper: quick connectivity check
# ============================================================

def check_ollama_available(host="http://localhost:11434"):
    """Return True if an Ollama server is reachable at host, else False.
    Used by pipeline_ollama.py to fail early with a helpful message."""
    try:
        client = ollama.Client(host=host)
        client.list()
        return True
    except Exception:
        return False


def list_ollama_models(host="http://localhost:11434"):
    """Return list of installed model names, or [] if unreachable."""
    try:
        client = ollama.Client(host=host)
        models = client.list().get("models", [])
        return [m.get("model") or m.get("name") for m in models]
    except Exception:
        return []


if __name__ == "__main__":
    print("Ollama connectivity check...")
    if not check_ollama_available():
        print("  Ollama server NOT reachable at http://localhost:11434")
        print("  Install from https://ollama.com and run `ollama serve`.")
    else:
        print("  Server reachable.")
        models = list_ollama_models()
        print(f"  Installed models: {models}")
