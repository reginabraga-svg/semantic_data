"""
Schema extractor for CorpOnto.owl
Produces a compact, LLM-friendly description of the ontology schema
that fits in a system prompt.
"""
from owlready2 import *
import re

def extract_schema(onto_path):
    onto = get_ontology(onto_path).load()
    ns_uri = onto.base_iri

    classes_info = []
    for cls in onto.classes():
        parents = [p.name for p in cls.is_a if hasattr(p, 'name') and p.name != 'Thing']
        # Subclasses
        subclasses = [sc.name for sc in cls.subclasses()]
        classes_info.append({
            "name": cls.name,
            "parents": parents,
            "subclasses": subclasses,
            "instance_count": len(list(cls.instances()))
        })

    obj_props = []
    for prop in onto.object_properties():
        domain = [d.name for d in prop.domain if hasattr(d, 'name')]
        range_ = [r.name for r in prop.range if hasattr(r, 'name')]
        obj_props.append({
            "name": prop.name,
            "domain": domain,
            "range": range_
        })

    data_props = []
    for prop in onto.data_properties():
        domain = [d.name for d in prop.domain if hasattr(d, 'name')]
        range_ = [str(r) for r in prop.range]
        data_props.append({
            "name": prop.name,
            "domain": domain,
            "range": range_
        })

    # Sample data property values to help LLM understand the data
    sample_values = {}
    for prop in onto.data_properties():
        seen = set()
        for ind in list(onto.individuals())[:200]:
            val = getattr(ind, prop.name, None)
            if val:
                if isinstance(val, list):
                    for v in val[:2]:
                        seen.add(str(v))
                else:
                    seen.add(str(val))
                if len(seen) >= 5:
                    break
        sample_values[prop.name] = sorted(seen)[:5]

    return {
        "namespace": ns_uri,
        "classes": classes_info,
        "object_properties": obj_props,
        "data_properties": data_props,
        "sample_data_values": sample_values
    }


def format_schema_for_llm(schema):
    """Compact textual representation that fits in a system prompt."""
    lines = []
    lines.append(f"Ontology namespace prefix: : <{schema['namespace']}>")
    lines.append("")
    lines.append("=== Classes (with subclass hierarchy and instance counts) ===")
    # Build a class tree
    root_classes = [c for c in schema['classes'] if not c['parents']]
    name_to_cls = {c['name']: c for c in schema['classes']}

    def render_class(c, depth=0):
        line = f"{'  ' * depth}- {c['name']} ({c['instance_count']} instances)"
        lines.append(line)
        for sub_name in c['subclasses']:
            if sub_name in name_to_cls:
                render_class(name_to_cls[sub_name], depth + 1)

    rendered = set()
    for c in root_classes:
        render_class(c)
        rendered.add(c['name'])
    # render leftovers (classes with parents that weren't reached)
    for c in schema['classes']:
        if c['name'] not in rendered:
            ancestors = c['parents']
            already = any(a in [x['name'] for x in schema['classes']] for a in ancestors)
            if not already:
                render_class(c)
                rendered.add(c['name'])

    lines.append("")
    lines.append("=== Object properties (domain -> range) ===")
    for p in schema['object_properties']:
        d = ', '.join(p['domain']) if p['domain'] else '?'
        r = ', '.join(p['range']) if p['range'] else '?'
        lines.append(f"- :{p['name']}  ({d} -> {r})")

    lines.append("")
    lines.append("=== Data properties (domain -> XSD type) ===")
    for p in schema['data_properties']:
        d = ', '.join(p['domain']) if p['domain'] else '?'
        r = ', '.join(p['range']) if p['range'] else '?'
        samples = schema['sample_data_values'].get(p['name'], [])
        sample_str = f"  [examples: {', '.join(samples[:3])}]" if samples else ""
        lines.append(f"- :{p['name']}  ({d} -> {r}){sample_str}")

    return '\n'.join(lines)


if __name__ == "__main__":
    schema = extract_schema("file:///home/claude/CorpOnto.owl")
    text = format_schema_for_llm(schema)
    print(text)
    print(f"\nSchema text length: {len(text)} chars")
    with open("/home/claude/corponto_schema.txt", "w") as f:
        f.write(text)
