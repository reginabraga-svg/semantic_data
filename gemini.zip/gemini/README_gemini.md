# Intelligent Layer with Gemini API — Setup and Run Guide

This guide walks you through running the Intelligent Layer pipeline end-to-end on your own machine, using Google's free Gemini API for the two language-model stages (NL → SPARQL translation and response synthesis). All other components — schema extraction, SPARQL execution against CorpOnto, and PROV-O lineage enrichment — run deterministically against your two ontology files.

**Why Gemini for this project:** Google's Gemini API has a generous free tier (typically 1,500 requests/day on Gemini 2.5 Flash), requires no credit card, and produces SPARQL of comparable quality to GPT-4o-mini. For 18 questions × 2 calls = 36 requests per full run, you can run the pipeline dozens of times per day at zero cost.

## What you need

- A computer with internet access. No special hardware required — all the LLM compute happens at Google.
- Python 3.10 or newer.
- Your two ontology files: `CorpOnto.owl` and `proveniencia.owl`.
- A Google account (for the Gemini API key).

---

## Step 1 — Get a free Gemini API key

1. Open https://aistudio.google.com/apikey in your browser.
2. Sign in with your Google account.
3. Click **"Create API key"**.
4. Choose a Google Cloud project, or let Google AI Studio create one for you (default works fine for personal use).
5. Copy the API key — it starts with `AIza...`. You won't see it again, so save it somewhere safe.

That's the whole process: no credit card, no billing setup, no team verification.

---

## Step 2 — Install Python dependencies

In your terminal:

```bash
pip install owlready2 rdflib google-genai
```

That's all. Three packages total.

---

## Step 3 — Set the API key as an environment variable

**Linux / macOS:**
```bash
export GEMINI_API_KEY=AIza...
```

**Windows (PowerShell):**
```powershell
$env:GEMINI_API_KEY="AIza..."
```

**Windows (Command Prompt):**
```cmd
set GEMINI_API_KEY=AIza...
```

To persist the key across terminal sessions, add the `export` line to your shell config file (`~/.bashrc`, `~/.zshrc`, or `~/.profile` on Linux/Mac).

---

## Step 4 — Place your ontology files

Put `CorpOnto.owl` and `proveniencia.owl` somewhere on disk. The pipeline accepts paths as arguments. The simplest layout:

```
intelligent_layer/
├── schema_extractor.py
├── executor.py
├── gemini_clients.py
├── pipeline_gemini.py
├── README_gemini.md
├── CorpOnto.owl           ← here
└── proveniencia.owl       ← here
```

---

## Step 5 — Quick connectivity check (optional, recommended)

Before the full run, verify your key works:

```bash
cd intelligent_layer
python3 gemini_clients.py
```

You should see:
```
Gemini connectivity check...
  Reachable: OK
```

If you get an error, recheck Step 1 and Step 3.

---

## Step 6 — Run the full pipeline

From inside `intelligent_layer/`:

```bash
python3 pipeline_gemini.py \
  --corponto ./CorpOnto.owl \
  --proveniencia ./proveniencia.owl
```

Or, if your ontologies are at the default `/home/claude/` location:

```bash
python3 pipeline_gemini.py
```

The pipeline will:

1. **Check Gemini connectivity** with your API key.
2. **Extract schema** from `CorpOnto.owl` (~150 ms, deterministic).
3. **Load both ontologies** into the in-memory triplestore.
4. **For each of the 18 questions**:
   - Send the question + schema to Gemini, parse the generated SPARQL.
   - Execute the generated SPARQL against the populated Gold ontology.
   - Enrich the result with provenance lineage from PROV-O.
   - Also execute the hand-curated reference SPARQL and compare result sets.
   - Send the question + SPARQL + results to Gemini for the natural-language answer.
   - Record per-stage latency.
5. **Print aggregate statistics**: SPARQL correctness (exact / partial / no match against the reference), median latency per stage, end-to-end latency.
6. **Save a full JSON report** to `intelligent_layer_gemini_results.json`.

Expected total runtime: **roughly 2 to 5 minutes** for the full 18 questions. Gemini 2.5 Flash is fast — each request typically takes 1-3 seconds.

---

## Step 7 — Read the results

Console output shows, per question:
- The generated SPARQL (first 10 lines)
- Number of rows from LLM-generated SPARQL vs. reference SPARQL
- Correctness label (`exact_match` / `partial_match` / `no_match`)
- The natural-language answer
- Per-stage latency

Aggregate at the end summarizes:
- **SPARQL correctness rate** across the 18 questions
- **Median latency** per stage
- **Breakdown by category** (English CQs, Portuguese CQs, natural questions)

The JSON report contains every generated SPARQL, every row of results, every answer, every timing. Open with any text editor or `jq`.

---

## Useful flags

Run a subset (useful for debugging):
```bash
python3 pipeline_gemini.py --questions 1,4,13
```

Skip response synthesis (halves API calls, faster):
```bash
python3 pipeline_gemini.py --no-synth
```

Add pacing delay between calls (helps with strict rate limits):
```bash
python3 pipeline_gemini.py --delay 1.0
```

Use a different Gemini model:
```bash
python3 pipeline_gemini.py --sparql-model gemini-2.5-pro
```
(Note: pro models have lower free-tier rate limits but higher quality.)

---

## Free-tier rate limits

Gemini's free tier on the standard `gemini-2.5-flash` model allows around 10-15 requests per minute and roughly 1,500 requests per day. For the 18-question pipeline:

- With synthesis: 36 API calls total
- Without synthesis: 18 API calls total

Both fit comfortably in the free daily allowance, even running the pipeline 30+ times. If you hit a rate limit, add `--delay 5` to space calls 5 seconds apart.

---

## What to report in the paper

After the run completes, you'll have hard numbers to replace the mock-derived numbers currently in Section 6.6 and Table 5:

| Currently reported (from mocks) | Replace with |
|---|---|
| "non-empty answer rate 88.9%" | **SPARQL correctness rate** (exact_match against reference) — a stronger metric measuring semantic correctness, not just non-empty results |
| "SPARQL exec median 6.5 ms" | Keep — already real (deterministic component) |
| (no LLM latency reported) | Median end-to-end latency including the LLM stages |
| "Mock implementations in place of live language-model calls" | Replace with: "Gemini 2.5 Flash (Google) used for both NL-to-SPARQL translation and response synthesis" |

The fact that you're using a free-tier model is also a methodological strength: it shows the architecture works with widely-accessible LLMs, not only with premium proprietary models.

---

## Pipeline architecture summary

```
                      ┌─────────────────────────────────┐
                      │  CorpOnto.owl (Gold ontology)   │
                      │  proveniencia.owl (PROV-O)      │
                      └──────────────┬──────────────────┘
                                     │
              ┌──────────────────────┴──────────────────────┐
              │  schema_extractor.py   (deterministic)      │
              │  → compact schema text for LLM context      │
              └──────────────────────┬──────────────────────┘
                                     │
   User question  ────────►  ┌───────┴────────────┐
   (EN or PT)                │ gemini_clients.py  │  Gemini 2.5 Flash
                             │ NL → SPARQL        │  (Google API, free tier)
                             └───────┬────────────┘
                                     │
                                     ▼
                             ┌────────────────────┐
                             │ executor.py        │
                             │ SPARQL execution   │  ← rdflib + owlready2
                             │ + lineage from     │     (deterministic)
                             │ proveniencia.owl   │
                             └───────┬────────────┘
                                     │
                                     ▼
                             ┌────────────────────┐
                             │ gemini_clients.py  │  Gemini 2.5 Flash
                             │ Response synthesis │  (Google API, free tier)
                             └───────┬────────────┘
                                     │
                                     ▼
                     NL answer with citations + provenance footer
```

---

## Troubleshooting

**"No API key set"**: confirm `echo $GEMINI_API_KEY` shows your key. On a fresh terminal you may need to re-export it.

**"Gemini API not reachable"**: corporate firewalls sometimes block `generativelanguage.googleapis.com`. Try from a personal network or use a phone hotspot.

**"Resource exhausted" / 429 errors**: you hit the rate limit. Add `--delay 5` to slow down, or wait a minute.

**Generated SPARQL fails to execute**: the LLM occasionally invents property names. The pipeline logs the error in the JSON report and continues. Look at `generated_sparql` in the JSON to see what went wrong.

**Want to test with just one question first**: `python3 pipeline_gemini.py --questions 1`. Takes ~10 seconds, tells you everything is set up correctly.

---

## Where each artifact ends up

- **Console output**: human-readable summary, printed live.
- **`intelligent_layer_gemini_results.json`**: machine-readable record of every step.

Both can be copied into the paper directly or used as supplementary material.
